//Implementa una función que reciba una matriz como parámetro y devuelva la matriz traspuesta .
function matrizTranspuesta(matriz) {
  let nuevaMatriz = [];
  for (let i = 0; i < matriz.length; i++) {
    nuevaMatriz[i] = [];
    for (let j = 0; j < matriz[i].length; j++) {
      nuevaMatriz[i][j] = matriz[j][i];
    }
  }
  return nuevaMatriz;
}
let matriz = [
  [0, 1, 2],
  [3, 4, 5],
  [6, 7, 8],
];

let resultado = matrizTranspuesta(matriz);

for (let fila of resultado) {
  console.log(fila);
}
