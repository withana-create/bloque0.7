//Implementa una función que reciba un texto(string)y que devuelva una matriz bidimensional de ancho 5 y de alto determinado que incorpore
//las palabras (elementos separados por espacios)del texto una por una de izquierda a derecha y de arriba a abajo .
//Mary tenía un corderito ,su piel era blanca como la nieve .

function crearMatriz(texto) {
  let palabras = texto.split(" "); //split (" ")me separa la cadena en cada lugar que detecte un espacio .
  let matriz = [];
  let ancho = 5;
  let fila = [];

  for (let i = 0; i < palabras.length; i++) {
    fila.push(palabras[i]); //a cada fila le vamos añadiendo palabras del texto.

    if (fila.length === ancho) {
      //cuando haya 5 palabras en cada fila ,añadimos a la matriz una nueva fila .
      matriz.push(fila);
      fila = [];
    }
  }
  if (fila.length > 0) {
    // si la longitud de la fila sigue siendo mayor que 0 quiere decir que aún quedan palabras por añadir.
    matriz.push(fila);
  }

  return matriz;
}
// texto = "Mary tenía un corderito , su piel era blanca como la nieve";
// texto = "Soy una tetera";
let resultado = crearMatriz(
  "Mary tenía un corderito , su piel era blanca como la nieve"
);
console.log(resultado);
