//Implementa una función que reciba por parámetro un array de elementos e imprima por pantalla si todos los elementos son unicos en la lista
//u otra lista con elementos repetidos en caso contrario .

function elementos(array) {
  let lista = array.split(",");

  let elementosRepetidos = [];

  for (let i = 0; i < lista.length; i++) {
    for (let j = i + 1; j < lista.length; j++) {
      if (lista[i] === lista[j]) {
        elementosRepetidos.push(lista[i]);
      }
    }
  }
  if (elementosRepetidos.length > 0) {
    console.log("elementos repetidos : " + elementosRepetidos);
  } else {
    console.log("no hay elementos repetidos");
  }
}

//Si al llamar a la función elementos pasamos otros parámetros como "uva,manzana,pera,platano" me va a indicar también si hay elementos repetidos o no.
// elementos("uva,manzana,pera,platano");
elementos("1,5,22,5,37,22,2,0");
